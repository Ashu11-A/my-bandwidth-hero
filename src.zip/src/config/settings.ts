const config = {
  port: '3002',
  minCompressLength: 1024
}
export default config
