import axios, { AxiosResponse } from 'axios';
import { pick } from 'underscore';
import { shouldCompress } from '../img/shouldCompress';
import { redirect } from '../img/redirect';
import { compress } from '../img/compress';
import { bypass } from '../img/bypass';
import { copyHeaders } from '../img/copyHeaders';
import https from 'https';
import { Request, Response } from 'express';

async function proxy(req: Request, res: Response) {
  try {
    console.log('Iniciando a requisição para:', req.params.url);

    const headersToCopy = ['cookie', 'dnt', 'referer'];
    const requestHeaders: any = {};
    for (const header of headersToCopy) {
      if (req.headers[header]) {
        requestHeaders[header] = req.headers[header];
      }
    }
    
    requestHeaders['user-agent'] = 'Bandwidth-Hero Compressor';
    requestHeaders['x-forwarded-for'] = req.headers['x-forwarded-for'] || req.ip;
    requestHeaders['via'] = '1.1 bandwidth-hero';

    const response: AxiosResponse<ArrayBuffer> = await axios.get(req.params.url, {
      headers: requestHeaders,
      timeout: 10000,
      maxRedirects: 5,
      responseType: 'arraybuffer',
      httpsAgent: new https.Agent({ rejectUnauthorized: false }),
    });

    const origin: ArrayBuffer = response.data;
    const buffer = Buffer.from(origin);

    // Criar um objeto falso do tipo IncomingMessage
    const fakeIncomingMessage: any = {
      headers: response.headers,
    };

    copyHeaders(fakeIncomingMessage, res);
    res.setHeader('content-encoding', 'identity');
    req.params.originType = response.headers['content-type'] || '';
    req.params.originSize = buffer.length.toString();

    if (shouldCompress(req)) {
      await compress(req, res, buffer);
    } else {
      await bypass(req, res, buffer);
    }
  } catch (err: any) {
    console.error(err)
    console.error(`Status: ${err?.response?.status ?? 'Error'} (${err?.response?.statusText ?? 'Error'}) host: ${err?.request?.host ?? 'Error'}`);
    return redirect(req, res);
  }
}

export { proxy };
